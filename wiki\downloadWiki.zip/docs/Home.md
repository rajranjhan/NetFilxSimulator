**Project Description**

WPF FIX protocol Simulator built against QuickFix engine.

This is in Alpha stage:

It is tested with equity orders.  You can configure it to send executions for orders it receives.  

Next release will support Cancel/Replace order messages and some more GUI improvements.



It uses following

Ninject for IoC
Calibrun.micro for MVVM framework
QuickFixEngine for Fix Protocol
Log4net for Logging
RibbonControls

